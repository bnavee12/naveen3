# data_acquisition_terraform
Terraform layer for data_acquisition AWS infrastructure. This repository will be designed to support multiple environments:
-`nonprod-shared` - Contains account-level infrastructure for NonProduction/Non-PHI account (575066535343). It instantiates the `vpc` module, which includes data_acquisition account-level resources such as a VPC and S3 bucket.
-`dev` - Contains a logical environment that sits on top of the infrastructure created by data_acquisition non-prod shared environment. This can contain isolated infrastructure for development purposes.
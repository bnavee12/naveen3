<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | 0.15.5 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 3.38 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2_latest"></a> [ec2\_latest](#module\_ec2\_latest) | ../../modules/ec2_latest | n/a |

## Resources

| Name | Type |
|------|------|
| [terraform_remote_state.data_acquisition_vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | AWS region to create resources | `string` | `"us-east-1"` | no |
| <a name="input_env_prefix"></a> [env\_prefix](#input\_env\_prefix) | Environment specific prefix to uniquely identify resources for an environment. e.g. dev/qa/stg/prod or dev-joe | `string` | `"dev"` | no |
| <a name="input_logical_env"></a> [logical\_env](#input\_logical\_env) | Logical environment (one of dev\|stg\|prd) | `string` | `"dev"` | no |
| <a name="input_project"></a> [project](#input\_project) | Name of the project | `string` | `"data_acquisition_ingestion1"` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->

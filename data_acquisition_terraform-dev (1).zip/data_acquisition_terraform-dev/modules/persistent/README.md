# Persistent module

This is a singleton-style infrastructure module that contains account-level infrastructure. There should only be 1 instance of this in an AWS account. It provides:
- a VPC that can be shared with private and public subnets. Includes a NAT gateway
- An S3 bucket for general logging purposes
- An S3 bucket to store assets required to build ec2 instance(ingestion1).
- An S3 bucket used to archive unprocessed data sent from clients.

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_s3_ec2_build_bucket"></a> [s3\_ec2\_build\_bucket](#module\_s3\_ec2\_build\_bucket) | terraform-aws-modules/s3-bucket/aws | 2.11.1 |
| <a name="module_s3_logs_bucket"></a> [s3\_logs\_bucket](#module\_s3\_logs\_bucket) | terraform-aws-modules/s3-bucket/aws | 2.11.1 |
| <a name="module_s3_sourcedata_archive"></a> [s3\_sourcedata\_archive](#module\_s3\_sourcedata\_archive) | terraform-aws-modules/s3-bucket/aws | 2.11.1 |
| <a name="module_vpc"></a> [vpc](#module\_vpc) | terraform-aws-modules/vpc/aws | ~> v2.70 |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current_identity](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_azs"></a> [aws\_azs](#input\_aws\_azs) | VPC availability zones | `list` | <pre>[<br>  "us-east-1a"<br>]</pre> | no |
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | AWS region to create resources | `string` | `"us-east-1"` | no |
| <a name="input_bucket_name"></a> [bucket\_name](#input\_bucket\_name) | n/a | `string` | `"data-acquisition-ingestion1"` | no |
| <a name="input_env_prefix"></a> [env\_prefix](#input\_env\_prefix) | n/a | `string` | n/a | yes |
| <a name="input_global_tags"></a> [global\_tags](#input\_global\_tags) | n/a | `map(string)` | `{}` | no |
| <a name="input_private_subnets_cidr_blocks"></a> [private\_subnets\_cidr\_blocks](#input\_private\_subnets\_cidr\_blocks) | VPC CIDR blocks for private subnets | `list` | <pre>[<br>  "10.10.11.0/24"<br>]</pre> | no |
| <a name="input_project"></a> [project](#input\_project) | n/a | `string` | `"data_acquisition_ingestion1"` | no |
| <a name="input_public_subnets_cidr_blocks"></a> [public\_subnets\_cidr\_blocks](#input\_public\_subnets\_cidr\_blocks) | VPC CIDR blocks for public subnets | `list` | <pre>[<br>  "10.10.1.0/24"<br>]</pre> | no |
| <a name="input_vpc_cidr_block"></a> [vpc\_cidr\_block](#input\_vpc\_cidr\_block) | VPC CIDR block | `string` | `"10.10.0.0/16"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_vpc"></a> [vpc](#output\_vpc) | VPC-related outputs for the main VPC for the account |
<!-- END_TF_DOCS -->

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_cloudwatch-alerts"></a> [cloudwatch-alerts](#module\_cloudwatch-alerts) | git::https://github.optum.com/oaccoe/aws_monitoring.git//modules/cloudwatch-alerts | v2.5.9 |
| <a name="module_codedeploy_svc_role"></a> [codedeploy\_svc\_role](#module\_codedeploy\_svc\_role) | git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role | v4.0.0 |

## Resources

| Name | Type |
|------|------|
| [aws_codedeploy_app.app](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codedeploy_app) | resource |
| [aws_codedeploy_deployment_group.codedeploy_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codedeploy_deployment_group) | resource |
| [aws_eip.data_acquisition_ingestion1_eip](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eip) | resource |
| [aws_eip_association.eip_assoc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eip_association) | resource |
| [aws_iam_instance_profile.data_acquisition_ingestion1_server](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_instance_profile) | resource |
| [aws_iam_role.data_acquisition_ingestion1_server](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.instance_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy_attachment.CodeDeploy_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.ssm_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_instance.ingestion1-dev](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/instance) | resource |
| [aws_security_group.vpc_sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.vpc_security_group_rule_allow_optum_traffic](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_ami.latest-windows](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.ec2_assume_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alarms_email"></a> [alarms\_email](#input\_alarms\_email) | List of emails to recieve alerts | `list(string)` | <pre>[<br>  "abandi@optum.com",<br>  "roberts.derek@optum.com"<br>]</pre> | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The name of the app | `string` | `"data_acquisition-ingestion1"` | no |
| <a name="input_availability_zone"></a> [availability\_zone](#input\_availability\_zone) | n/a | `string` | `"us-east-1a"` | no |
| <a name="input_ebs_block_device_size"></a> [ebs\_block\_device\_size](#input\_ebs\_block\_device\_size) | n/a | `number` | `1024` | no |
| <a name="input_ec2_tag_name"></a> [ec2\_tag\_name](#input\_ec2\_tag\_name) | ec2 tag name to filter instances | `string` | `"optum:environment"` | no |
| <a name="input_ec2_tag_name_value"></a> [ec2\_tag\_name\_value](#input\_ec2\_tag\_name\_value) | ec2 tag name to filter instances in dev and prd environments | `string` | n/a | yes |
| <a name="input_env_prefix"></a> [env\_prefix](#input\_env\_prefix) | Environment specific prefix to uniquely identify resources for an environment. e.g. dev/qa/stg/prod or dev-joe | `string` | n/a | yes |
| <a name="input_global_tags"></a> [global\_tags](#input\_global\_tags) | n/a | `map(string)` | `{}` | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `any` | n/a | yes |
| <a name="input_logical_env"></a> [logical\_env](#input\_logical\_env) | Logical environment - one of dev\|stg\|prd | `string` | n/a | yes |
| <a name="input_project"></a> [project](#input\_project) | Name of the project | `string` | `"data_acquisition_ingestion1"` | no |
| <a name="input_root_volume_size"></a> [root\_volume\_size](#input\_root\_volume\_size) | n/a | `number` | `"120"` | no |
| <a name="input_root_volume_type"></a> [root\_volume\_type](#input\_root\_volume\_type) | n/a | `string` | `"gp3"` | no |
| <a name="input_server_name"></a> [server\_name](#input\_server\_name) | Name of the server | `string` | `"das_ingestion1"` | no |
| <a name="input_servicenow_url"></a> [servicenow\_url](#input\_servicenow\_url) | servicenow API URL | `string` | n/a | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | n/a | `any` | n/a | yes |
| <a name="input_vpc_private_subnet_ids"></a> [vpc\_private\_subnet\_ids](#input\_vpc\_private\_subnet\_ids) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_data_acquisition_vpc_sg"></a> [data\_acquisition\_vpc\_sg](#output\_data\_acquisition\_vpc\_sg) | n/a |
<!-- END_TF_DOCS -->
